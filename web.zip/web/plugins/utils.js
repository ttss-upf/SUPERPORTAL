function lerp(a, b, f) {
  return a * (1 - f) + b * f;
}
