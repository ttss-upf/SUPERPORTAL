var Config = {
  // HTTP_URL: "https://ecv-etic.upf.edu/node/9022/"
  // WS_URL: "wss://ecv-etic.upf.edu/node/9022/ws/",
  HTTP_URL: "http://localhost:9022/",
  WS_URL: "ws://localhost:9022/",
};

// background of login page
document.getElementById("LandingImg").src =
  STATIC_RESOURCE_ROOT + "pixelportal1.png";
